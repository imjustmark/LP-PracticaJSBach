from antlr4 import *
from jsbachLexer import jsbachLexer
from jsbachParser import jsbachParser
from jsbachVisitor import jsbachVisitor

import sys
import os
import numpy as np


class PracticaVisitor(jsbachVisitor):

    def __init__(self):
        self.dicc = {}
        self.pilaDeDiccionaris = [self.dicc]
        self.contextFuncions = {}
        self.notes = {}
        self.nom_notes = []
        self.pentagrama = []

        lletres = "CDEFGAB"
        self.notes['A0'] = 0
        self.nom_notes.append('A0')
        self.notes['B0'] = 1
        self.nom_notes.append('B0')
        j = 2
        for i in range(1, 8):
            for lletra in lletres:
                num = str(i)
                nota = lletra + num
                self.notes[nota] = j
                self.nom_notes.append(nota)
                if i == 4:
                    self.notes[lletra] = j
                j += 1
        self.notes['C8'] = j
        self.nom_notes.append('C8')

    def visitRoot(self, ctx: jsbachParser.RootContext):
        l = list(ctx.getChildren())

        proc = None
        parametre = False
        found = False
        if (len(sys.argv) > 2):
            proc = sys.argv[2]
            parametre = True

        for i in range(0, len(l)):
            nom_aux = l[i].getText()
            nom = ""
            c = nom_aux[0]
            index = 1
            while c != '|' and nom_aux != "<EOF>":
                nom += c
                c = nom_aux[index]
                index += 1
            if nom == 'Main' or (nom == proc and parametre):
                j = i
                found = True
            else:
                self.visit(l[i])

        if found:
            self.visit(l[j])
        else:
            raise Exception("El programa manca un procediment Main.")
        pent_aux = np.array(self.pentagrama)
        pentagrama = pent_aux.flatten()

        if len(pentagrama) == 0:
            return

        nom_arxiu_entrada = sys.argv[1][0:len(sys.argv[1])-4]
        nom_lilypond = nom_arxiu_entrada + ".ly"
        nom_wav = nom_arxiu_entrada + ".wav"
        nom_midi = nom_arxiu_entrada + ".midi"
        nom_mp3 = nom_arxiu_entrada + ".mp3"
        f = open(nom_lilypond, "w", encoding="utf-8")
        f.write("""\\version "2.20.0"
        \score {
            \\absolute {
                \\tempo 4 = 120
                """)
        for nota in pentagrama:
            nom_nota = self.nom_notes[nota]
            num_escala = int(nom_nota[1])
            num_comes = abs(num_escala - 3)
            f.write(nom_nota[0].lower())

            if num_escala > 3:
                for i in range(num_comes):
                    f.write("'")
            else:
                for i in range(num_comes):
                    f.write(",")
            f.write('4 ')
        f.write("""
            }
            \layout { }
            \midi { }
        }
        """)
        f.close()
        os.system("lilypond " + nom_lilypond)
        os.system("timidity -Ow -o " + nom_wav + " " + nom_midi)
        os.system("ffmpeg -i " + nom_wav + " -codec:a libmp3lame -qscale:a 2 " + nom_mp3)

    # Visit a parse tree produced by jsbachParser#Main.
    def visitMain(self, ctx: jsbachParser.MainContext):
        l = list(ctx.getChildren())
        for i in range(2, len(l)):
            self.visit(l[i])

    # Visit a parse tree produced by jsbachParser#Procediment.
    def visitProcediment(self, ctx: jsbachParser.ProcedimentContext):
        l = list(ctx.getChildren())
        nom = l[0].getText()
        if nom in self.contextFuncions:
            raise Exception("Error en la definició de Procediments: definició de dos procediments amb el mateix nom.")

        if len(sys.argv) > 2 and nom == sys.argv[2]:
            for i in range(2, len(l)):
                self.visit(l[i])

        else:
            param = []
            i = 1
            while (i < len(l)) and (l[i].getText() != '|:'):
                if l[i].getText() in param:
                    raise Exception("Error en la definició de Procediments: definició de dos paràmetres amb el mateix nom.")
                param.append(l[i].getText())
                i += 1
            i += 1
            bloc = []
            while (i < len(l)) and (l[i].getText() != ':|'):
                bloc.append(l[i])
                i += 1
            contextFuncio = (param, bloc)
            self.contextFuncions[nom] = contextFuncio

    # Visit a parse tree produced by jsbachParser#Write.
    def visitWrite(self, ctx: jsbachParser.WriteContext):
        l = list(ctx.getChildren())
        n = len(l)
        for i in range(1, n):
            thingToBeWritten = l[i]
            if thingToBeWritten.getText()[0] == '"':
                print(l[i].getText()[1:(len(l[i].getText())-1)], end=' ')
            else:
                var = self.visit(l[i])
                if type(var) == list:
                    print('{', end='')
                    for j in range(0, len(var)):
                        v = var[j]
                        if j == len(var) - 1:
                            print(v, end='')
                        else:
                            print(v, end=' ')
                    print('}', end='')
                else:
                    print(var, end='')
                print(end=' ')
        print()

    # Visit a parse tree produced by jsbachParser#Read.
    def visitRead(self, ctx: jsbachParser.ReadContext):
        l = list(ctx.getChildren())
        var = l[1].getText()
        valor = int(input())
        self.pilaDeDiccionaris[-1][var] = valor

    # Visit a parse tree produced by jsbachParser#Assignacio.
    def visitAssignacio(self, ctx: jsbachParser.AssignacioContext):
        l = list(ctx.getChildren())
        var = l[0].getText()
        self.pilaDeDiccionaris[-1][var] = self.visit(l[2])

    # Visit a parse tree produced by jsbachParser#IfElse.
    def visitIfElse(self, ctx: jsbachParser.IfElseContext):
        l = list(ctx.getChildren())
        i = 3
        j = 3
        while l[j].getText() != ":|":
            j += 1
        if self.visit(l[1]) == 1:
            for x in range(i, j):
                self.visit(l[x])
        else:
            for x in range(j + 3, len(l)-1):
                self.visit(l[x])

    # Visit a parse tree produced by jsbachParser#If.
    def visitIf(self, ctx: jsbachParser.IfContext):
        l = list(ctx.getChildren())
        if self.visit(l[1]) == 1:
            for i in range(3, len(l)-1):
                self.visit(l[i])
        else:
            return

    # Visit a parse tree produced by jsbachParser#While.
    def visitWhile(self, ctx: jsbachParser.WhileContext):
        l = list(ctx.getChildren())
        while self.visit(l[1]) == 1:
            for i in range(3, len(l)-1):
                self.visit(l[i])

    # Visit a parse tree produced by jsbachParser#Invocacio.
    def visitInvocacio(self, ctx: jsbachParser.InvocacioContext):
        l = list(ctx.getChildren())
        # 1: Determinem el procediment que volem invocar
        nomProcediment = l[0].getText()
        if nomProcediment in self.contextFuncions:
            tupla = self.contextFuncions[nomProcediment]
        else:
            raise Exception("Error en crida a Procediment: El Procediment no existeix")

        # 2: Determinem els parametres que volem passar
        parametres = []
        for i in range(1, len(l)):
            parametres.append(self.visit(l[i]))
        if len(tupla[0]) != len(parametres):
            raise Exception("Error en crida a Procediment: Nombre de paràmetres incorrecte")
        else:
            # 3: Assignem a les variables del procediment els valors dels parametres
            nouDiccionari = {}
            for k in range(0, len(tupla[0])):
                nouDiccionari[tupla[0][k]] = parametres[k]
            self.pilaDeDiccionaris.append(nouDiccionari)
            bloc = tupla[1]
            for i in range(0, len(bloc)):
                self.visit(bloc[i])
            self.pilaDeDiccionaris.pop()

    # Visit a parse tree produced by jsbachParser#Parentesis.
    def visitParentesis(self, ctx: jsbachParser.ParentesisContext):
        l = list(ctx.getChildren())
        return self.visit(l[1])

    # Visit a parse tree produced by jsbachParser#Var.
    def visitVar(self, ctx: jsbachParser.VarContext):
        l = list(ctx.getChildren())
        var = l[0].getText()
        variables = self.pilaDeDiccionaris[-1]
        if var in variables:
            return variables[var]
        else:
            return 0

    # Visit a parse tree produced by jsbachParser#ResSum.
    def visitResSum(self, ctx: jsbachParser.ResSumContext):
        l = list(ctx.getChildren())
        operation = l[1].getText()
        if operation == '-':
            return self.visit(l[0]) - self.visit(l[2])
        else:
            return self.visit(l[0]) + self.visit(l[2])

    # Visit a parse tree produced by jsbachParser#DivModMul.
    def visitDivModMul(self, ctx: jsbachParser.DivModMulContext):
        l = list(ctx.getChildren())
        operation = l[1].getText()
        if operation == '/':
            if self.visit(l[2]) == 0:
                raise Exception("Error, divisió per zero")
            else:
                return self.visit(l[0]) // self.visit(l[2])
        elif operation == '*':
            return self.visit(l[0]) * self.visit(l[2])
        else:
            return self.visit(l[0]) % self.visit(l[2])

    # Visit a parse tree produced by jsbachParser#Valor.
    def visitValor(self, ctx: jsbachParser.ValorContext):
        l = list(ctx.getChildren())
        return int(l[0].getText())

    # Visit a parse tree produced by jsbachParser#Compare.
    def visitCompare(self, ctx: jsbachParser.CompareContext):
        l = list(ctx.getChildren())
        operation = l[1].getText()
        if operation == '=':
            if self.visit(l[0]) == self.visit(l[2]):
                return 1
            else:
                return 0
        elif operation == '/=':
            if self.visit(l[0]) != self.visit(l[2]):
                return 1
            else:
                return 0
        elif operation == '>':
            if self.visit(l[0]) > self.visit(l[2]):
                return 1
            else:
                return 0
        elif operation == '<':
            if self.visit(l[0]) < self.visit(l[2]):
                return 1
            else:
                return 0
        elif operation == '>=':
            if self.visit(l[0]) >= self.visit(l[2]):
                return 1
            else:
                return 0
        else:
            if self.visit(l[0]) <= self.visit(l[2]):
                return 1
            else:
                return 0

        # Visit a parse tree produced by jsbachParser#Concat.
    def visitConcat(self, ctx: jsbachParser.ConcatContext):
        l = list(ctx.getChildren())
        nom_llista = l[0].getText()
        nou_valor = self.visit(l[2])
        self.pilaDeDiccionaris[-1][nom_llista].append(nou_valor)

    # Visit a parse tree produced by jsbachParser#Tisores.
    def visitTisores(self, ctx: jsbachParser.TisoresContext):
        l = list(ctx.getChildren())
        nom_llista = l[1].getText()
        index = self.visit(l[3])
        if index > len(self.pilaDeDiccionaris[-1][nom_llista]):
            raise Exception("Error en l'accés a un element d'una llista: l'índex no existeix en la llista.")
        self.pilaDeDiccionaris[-1][nom_llista].pop(index-1)

    # Visit a parse tree produced by jsbachParser#LengthList.
    def visitLengthList(self, ctx: jsbachParser.LengthListContext):
        l = list(ctx.getChildren())
        nom_llista = l[1].getText()
        return len(self.pilaDeDiccionaris[-1][nom_llista])

    # Visit a parse tree produced by jsbachParser#Llista.
    def visitLlista(self, ctx: jsbachParser.LlistaContext):
        l = list(ctx.getChildren())
        llista = []
        for i in range(1, len(l)-1):
            llista.append(self.visit(l[i]))
        return llista

    # Visit a parse tree produced by jsbachParser#Element.
    def visitElement(self, ctx: jsbachParser.ElementContext):
        l = list(ctx.getChildren())
        nomllista = l[0].getText()
        if type(self.pilaDeDiccionaris[-1][nomllista]) != list:
            raise Exception("Error en l'accés a un element d'una llista: la variable accedida no és una llista.")
        index = self.visit(l[2])
        if index > len(self.pilaDeDiccionaris[-1][nomllista]):
            raise Exception("Error en l'accés a un element d'una llista: l'índex no existeix en la llista.")
        return self.pilaDeDiccionaris[-1][nomllista][index-1]

    # Visit a parse tree produced by jsbachParser#Nota.
    def visitNota(self, ctx: jsbachParser.NotaContext):
        nota = list(ctx.getChildren())[0]
        nota_aux = str(nota)
        return self.notes[nota_aux]

    # Visit a parse tree produced by jsbachParser#Play.
    def visitPlay(self, ctx: jsbachParser.PlayContext):
        l = list(ctx.getChildren())
        valor = self.visit(l[1])
        if (type(valor) == list):
            for i in range(0, len(valor)):
                if (valor[i] > 0) and (valor[i] < len(self.nom_notes)):
                    self.pentagrama.append(valor[i])
        elif (valor > 0) and valor < len(self.nom_notes):
            self.pentagrama.append(valor)

input_stream = FileStream(sys.argv[1])

lexer = jsbachLexer(input_stream)
token_stream = CommonTokenStream(lexer)
parser = jsbachParser(token_stream)
tree = parser.root()

visitor = PracticaVisitor()
visitor.visit(tree)

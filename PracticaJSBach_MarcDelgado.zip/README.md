# JSBACH

JSBach is a programming language created by Programming Languages (LP) professors at FIB-UPC, as part of the practical for the course Q2 2021-2022.

The practical consists on developing a compiler for said language, with details on its syntax and instructions provided by our professors.

On this folder you may find a file containing the grammatical structure of the compiler, which was created using [ANTLR4](https://www.antlr.org/), *jsbach.g*. You may also find a Python file, which contains the visitor required to evaluate the expressions captured by the grammar as well as the code to execute the compiler, *jsbach.py*. 

## Usage

To use the JSBach compiler you must generate an entry file, implemented in JSBach, which we will call *input.jsb*, but can be named as you wish.

Once generated, in order to use the compiler you must execute:

```bash
python3 jsbach.py input.jsb
```

## Outcome

After executing the compiler on your input file and if your program played any notes, four different files will have been generated:
- *input.pdf*, which will contain the partiture representation of the notes played in the program.
- And three audio files which contain the sounds made by said notes, *input.midi*, *input.wav* and *input.mp3*.
    
It is important to remark that **only** if your JSBach program played any notes will these files be generated. Otherwise, the program will be executed but **no files will be generated**. This is done in order not to generate empty partitures and silent melodies.

## Details

The arithmetical expressions such as *x + 3* should be written with correct spacing between the operator and the operands, that is:

**operand** *blank* **operator** *blank* **operand**

## Author
Marc Delgado Sánchez (marc.delgado.sanchez@estudiantat.upc.edu)